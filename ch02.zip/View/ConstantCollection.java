package ch02.View;

import java.awt.Font;

public class ConstantCollection {
	static Font ServerLogfont = new Font("d2coding", 0, 10);
	static Font Chatfont = new Font("d2coding", 0, 10);
	static Font font = new Font("d2coding", 0, 10);

}
