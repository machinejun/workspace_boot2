package ch02.Client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JOptionPane;

import ch02.Server.ServerData;
import ch02.Server.User;
import ch02.View.ClientView;

public class ClientServiceImpl implements ClientService{
	
	private ClientView clientView;
	private Socket socket;
	
	private InputStream inputStream;
	private OutputStream outputStream;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
	private Vector<String> Nicknames;
	
	
	public ClientServiceImpl(ClientView clientView) {
		this.clientView = clientView;
		this.Nicknames = new Vector<String>();
	}
	
	@Override
	public boolean login(String ip, int portNumber, String nickName) {
		try {
			socket = new Socket(ip, portNumber);
			inputStream = socket.getInputStream();
			dataInputStream = new DataInputStream(inputStream);
			
			outputStream = socket.getOutputStream();
			dataOutputStream = new DataOutputStream(outputStream);
			System.out.println("login success");
			String log = "admission" + "/" + nickName;
			sentLog(log);
			clientView.updateUser();
			runServer();
			return true;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "연결실패!", "알림",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
	}
	

	@Override
	public void runServer() {
		
			new Thread(new Runnable() {
				@Override
				public void run() {
					while(true) {
						try {
							String log = dataInputStream.readUTF();
							String[] protocol = getLog(log);
							
							switch (protocol[0]) {
							case "NewUser":
								
								break;

							default:
								break;
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
				}
			}).start();	
	}

	@Override
	public void sentMsg(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createRoom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void exitRoom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chatMsg() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sentLog(String log) {
		try {
			dataOutputStream.writeUTF(log);
			dataOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public String[] getLog(String log) {
		StringTokenizer dividing = new StringTokenizer(log, "/");
		String logHead = dividing.nextToken();
		String logBody = dividing.nextToken();
		
		System.out.println("logHead: " + logHead);
		System.out.println("logBody: " + logBody);
		
		String[] protocol = new String[2];
		
		protocol[0] = logHead;
		protocol[1] = logBody;
		
		return protocol;
	}

	

	
	

}
