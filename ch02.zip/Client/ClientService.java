package ch02.Client;

import ch02.Server.User;

public interface ClientService {
	
	boolean login(String ip, int portNumber, String nickName);
	void sentMsg(User user);
	void runServer();
	void sentLog(String log);
	void createRoom();
	void exitRoom();
	void chatMsg();
	String[] getLog(String log);
}
