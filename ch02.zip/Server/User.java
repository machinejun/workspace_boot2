package ch02.Server;

import java.net.Socket;

import lombok.Getter;

@Getter
public class User {
	private String nickName;
	private int roomNumber;
	private Socket userSocket;
	
	public User(String nickName, Socket userSocket) {
		this.nickName = nickName;
		this.userSocket = userSocket;
		roomNumber = 0;
	}
	
	private void inputUserData() {
		//
	}

}
