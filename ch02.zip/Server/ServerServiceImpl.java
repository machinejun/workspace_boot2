package ch02.Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import ch02.View.ServerView;
import lombok.Data;

@Data
public class ServerServiceImpl implements ServerService{
	
	private ServerView serverView;
	private InputStream inputStream;
	private OutputStream outputStream;
	private DataInputStream dataInputStream;
	private DataOutputStream dataOutputStream;
	
	private ServerSocket serverSocket;
	private ServerData serverData;
	private Socket socket;
	private ServerData dataList;
	
	private StringBuffer totalLog;
	
	public ServerServiceImpl(ServerView serverView) {
		this.serverView = serverView;
		totalLog = new StringBuffer();
		dataList = ServerData.getinstance();
		
	}
	

	@Override
	public void startNetwork(int portNumber) {
		try { 
			serverSocket = new ServerSocket(portNumber);
			totalLog.append("통신을 시작합니다\n");
			linkSomeone();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "이미 사용중인 포트입니다.", "Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} catch( Exception e) {
			JOptionPane.showMessageDialog(null, "잘못 입력하셨습니다.", "Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		
	}

	@Override
	public void linkSomeone() {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					try {
						socket = serverSocket.accept();
						runServer(socket);
						
					} catch (IOException e) {
						e.printStackTrace();
						break;
					}
				}
				
			}
		}).start();
		
	}
	
	@Override
	public void runServer(Socket socket) {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true) {
					try {
						inputStream = socket.getInputStream();
						dataInputStream = new DataInputStream(inputStream);
						
						outputStream = socket.getOutputStream();
						dataOutputStream = new DataOutputStream(outputStream);
						
						String log = dataInputStream.readUTF();
						serverView.showLog(log);
						
						String[] protocol = getLog(log);
						
						switch (protocol[0]) {
						case "Admission":
							//   admission/newUser
							User user = new User(protocol[1], socket);
							dataList.getUserlist().add(user);
							String admissionlog = "NewUser/" + protocol[1];
							broadcast(admissionlog);
							BasicDataRecept();
							break;
						case "Message":
							//   Message/caller>receiver@contents
							StringTokenizer divding = new StringTokenizer(protocol[1], ">|@");
							String caller = divding.nextToken();
							String receiver = divding.nextToken();
							String message = divding.nextToken();
							
							
							break;
						case "CreateRoom":	
							// CreateRoom/RoomNumber
							break;
						
						case "Chatting":
							//Chatting/RoomNumber@contents
							break;
						
						case "EnterRoom":
							// EnterRoom/RoomNumber@Nickname
							break;
						
						case "ExitRoom":
							// ExitRoom/RoomNumber@Nickname
						default:
							
							
						}
						
						
						
						
					} catch (IOException e) {
						for(int i = 0; i < serverData.getUserlist().size(); i++) {
							if(serverData.getUserlist().get(i).getUserSocket() == socket) {
								serverView.showLog(serverData.getUserlist().get(i).getNickName() + " : 사용자접속끊어짐\n");
							}
						}
						
					}
				}
			}
		}).start();
		
	}

	@Override
	public String[] getLog(String log) {
		StringTokenizer dividing = new StringTokenizer(log, "/");
		String logHead = dividing.nextToken();
		String logBody = dividing.nextToken();
		
		System.out.println("logHead: " + logHead);
		System.out.println("logBody: " + logBody);
		
		String[] protocol = new String[2];
		
		protocol[0] = logHead;
		protocol[1] = logBody;
		return protocol;
	}
	
	@Override
	public void broadcast(String log) {
		for(int i = 0; i < dataList.getUserlist().size(); i++) {
			User user = dataList.getUserlist().elementAt(i);
			sentLog(log);
		}
	}

	@Override
	public void sentLog(String log) {
		try {
			dataOutputStream.writeUTF(log);
			dataOutputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void BasicDataRecept() {
		for (User user : serverData.getinstance().getUserlist()) {
			String nickname = user.getNickName();
			sentLog("OldUser/" + nickname);
		}
		
		for (InnerRoom room : serverData.getinstance().getRoomlist()) {
			String roomNumber = room.getRoomNumber();
			sentLog("OldRoom/" + roomNumber);
		}
		
	}

	@Override
	public void createRoom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void exitRoom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printLog() {
		// TODO Auto-generated method stub
		
	}


	


	


	

}
