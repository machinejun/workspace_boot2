package ch02.Server;

public class InnerRoom {
	private String roomName;

	public InnerRoom(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomNumber() {
		return roomName;
	}

	public void setRoomNumber(String roomName) {
		this.roomName = roomName;
	}
}
