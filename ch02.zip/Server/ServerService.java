package ch02.Server;

import java.net.Socket;

/**
 * @protocol 
 * @author ITPS
 *
 */
public interface ServerService {
	
	void startNetwork(int portNumber);
	void linkSomeone();
	void runServer(Socket socket);
	String[] getLog(String log);
	void broadcast (String log);
	void sentLog(String log);
	void createRoom();
	void exitRoom();
	void printLog();
	void BasicDataRecept();
	
}
